AutoGeneS – Automatic Gene Selection
====================================

AutoGeneS is a toolkit to automatically select genes for bulk deconvolution.
