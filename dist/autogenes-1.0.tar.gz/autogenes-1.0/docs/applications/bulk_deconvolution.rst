Bulk deconvolution
==================
