Deconvolution
=============
