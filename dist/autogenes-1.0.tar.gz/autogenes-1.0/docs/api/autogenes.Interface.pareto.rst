autogenes.Interface.pareto
==========================

.. currentmodule:: autogenes

.. automethod:: Interface.pareto