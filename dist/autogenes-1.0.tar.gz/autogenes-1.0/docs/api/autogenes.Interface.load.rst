autogenes.Interface.load
========================

.. currentmodule:: autogenes

.. automethod:: Interface.load