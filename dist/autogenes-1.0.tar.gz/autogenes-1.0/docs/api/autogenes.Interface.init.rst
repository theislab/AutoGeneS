autogenes.Interface.init
========================

.. currentmodule:: autogenes

.. automethod:: Interface.init