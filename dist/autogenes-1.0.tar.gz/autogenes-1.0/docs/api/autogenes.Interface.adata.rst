autogenes.Interface.adata
=========================

.. currentmodule:: autogenes

.. automethod:: Interface.adata