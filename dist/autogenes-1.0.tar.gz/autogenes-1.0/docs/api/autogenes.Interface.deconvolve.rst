autogenes.Interface.deconvolve
==============================

.. currentmodule:: autogenes

.. automethod:: Interface.deconvolve