autogenes.Interface.pipeline
============================

.. currentmodule:: autogenes

.. automethod:: Interface.pipeline