autogenes.Interface.fitness\_matrix
===================================

.. currentmodule:: autogenes

.. automethod:: Interface.fitness_matrix