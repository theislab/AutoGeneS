autogenes.Interface.save
========================

.. currentmodule:: autogenes

.. automethod:: Interface.save