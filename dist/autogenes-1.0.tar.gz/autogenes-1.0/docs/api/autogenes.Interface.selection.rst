autogenes.Interface.selection
=============================

.. currentmodule:: autogenes

.. automethod:: Interface.selection