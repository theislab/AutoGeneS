autogenes.Interface.resume
==========================

.. currentmodule:: autogenes

.. automethod:: Interface.resume