autogenes.Interface.optimize
============================

.. currentmodule:: autogenes

.. automethod:: Interface.optimize