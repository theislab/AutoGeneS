autogenes.Interface.plot
========================

.. currentmodule:: autogenes

.. automethod:: Interface.plot