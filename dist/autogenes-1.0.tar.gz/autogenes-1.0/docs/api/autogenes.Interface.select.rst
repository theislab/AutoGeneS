autogenes.Interface.select
==========================

.. currentmodule:: autogenes

.. automethod:: Interface.select